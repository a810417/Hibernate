package tw.hibernatedemo.util;

public class TestJava1 {

	public static void main(String[] args) {
		System.out.println("安安 OK!!");

	}

}
